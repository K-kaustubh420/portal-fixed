import React from 'react'
import Proposal from './proposal'
import Navbar from '@/components/Navbar'
const page = () => {
  return (
    <div>
      <div> 
    <Navbar/>
    </div>
      <Proposal/>
    </div> 
  )
}

export default page
